from django.apps import AppConfig


class ChhotiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aditya'
